This project is meant to be the base project for all Roddy plugin projects.

* Version update to 1.0.28

  * JDK 1.8
  * Groovy 2.4
  * Roddy API 2.3

* Version update to 1.0.24
