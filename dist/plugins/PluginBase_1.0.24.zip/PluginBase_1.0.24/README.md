This project is meant to be the base project for all Roddy plugin projects.
