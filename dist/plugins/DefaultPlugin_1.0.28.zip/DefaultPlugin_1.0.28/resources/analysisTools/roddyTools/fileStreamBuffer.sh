#!/bin/sh

#PBS -q highmem
#PBS -l mem=120g

# Read a list of files and push them to n MemoryStreamer servers.

source ${CONFIG_FILE}

